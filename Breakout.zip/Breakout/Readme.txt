Controls

Menu

W & S - Select Level

SPACE - Start Level

Game

A - Move paddle left

D - Move paddle right

SPACE - Launch ball